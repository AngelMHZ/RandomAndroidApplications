package com.example.sensors;


import java.io.IOException;
import java.util.List;
import java.util.Locale;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class GPSActivity extends Activity {
	private LocationManager mngr;
	private LocationListener listener;
	private List<Address> addresses;
	
	private TextView displayLong;
	private TextView displayLat;
	private TextView displayAlt;
	private TextView displayLocName;
	
	
	boolean hasGPS;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_gps);
		
		mngr = (LocationManager) getSystemService(LOCATION_SERVICE);
		checkDevice();
		setInfo();
	}
	
	

	private void setInfo() {
		final Geocoder geocoder= new Geocoder(this, Locale.getDefault());
		listener = new LocationListener(){

			@Override
			public void onLocationChanged(Location location) {
				displayLong.setText(location.getLongitude() + " *");
				displayLat.setText(location.getLatitude() + " *");
				displayAlt.setText(location.getAltitude() + " meters above sea level");
				
				try {
		            
		            //Place your latitude and longitude
		            addresses = geocoder.getFromLocation(location.getLatitude(),location.getLongitude(), 1);
		            if(addresses.size() > 0) {
		             
		                displayLocName.setText(addresses.get(0).getAddressLine(1));
		                
		            }
		             
		            else{
		            	mngr.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 0, listener);
		            	displayLocName.setText("Location Name Not Found");
		            }
		      } 
		      catch (IOException e) {
		               Toast.makeText(getApplicationContext(),"Could not get address..!", Toast.LENGTH_LONG).show();
		      }
			}

			@Override
			public void onStatusChanged(String provider, int status,
					Bundle extras) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onProviderEnabled(String provider) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onProviderDisabled(String provider) {
				// TODO Auto-generated method stub
				
			}
			
		};
		mngr.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 0, listener);
		
		
	}



	private void checkDevice() {
		displayLong = (TextView) findViewById(R.id.displayLong);
		displayLat = (TextView) findViewById(R.id.displayLat);
		displayAlt = (TextView) findViewById(R.id.displayAlt);
		displayLocName = (TextView) findViewById(R.id.displayLocName);
		
		PackageManager PM= this.getPackageManager();
		
		hasGPS = PM.hasSystemFeature(PackageManager.FEATURE_LOCATION_GPS);
		
		if(!hasGPS){
			displayLong.setText("N/A");
			displayLat.setText("N/A");
			displayAlt.setText("N/A");
			displayLocName.setText("N/A");}
		
	}
	

	public void backPage(View view){
		Intent intent = new Intent(this, MainActivity.class);
		startActivity(intent);
	}
	
	/*
	 * Geocoder gcd = new GeoCode(this,Locale.getDefault);
	 * List <Address> addresses = gcd.getfromLocation(location,getlatitude, location.getlongitude());
	 * 
	 * if(addresses.size()>0){
	 * 		addresses.get(0).getLocality() // put this in textview
	 * }
	 */
}
