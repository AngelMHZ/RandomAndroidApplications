/*
 * Angel Hernandez
 * Comp 595MC
 * Sept 11, 2014
 * Project : Sensors app
 * Description: Displays the current value of available sensors. 
 * 				For unavailable sensors, the app detects and 
 * 				say that the sensor is unavailable on the device.
 * Version:
 * 	1.0: Working sensors and display
 */

package com.example.sensors;

import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends ActionBarActivity {
	private SensorManager mngr;
	private SensorEventListener listener;
	
	boolean hasAccel;
	boolean hasGys;
	boolean hasALS;
	boolean hasAMFS;
	boolean hasProx;
	boolean hasBaro;
	
	
	private TextView displayAccel;
	private TextView displayLinAccel;
	private TextView displayGravitySensor;
	private TextView displayGyroscope;
	private TextView displayALS;//Ambient Light Sensor
	private TextView displayAMFS;//Ambient Magnetic Field Sensor
	private TextView displayProx;//Proximity Sensor
	private TextView displayBaro;//Barometer
	private TextView displayATS;//Ambient Temperature Sensor
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mngr = (SensorManager) getSystemService(SENSOR_SERVICE);
		checkDevice();
		setInfo();
	}

	private void checkDevice() {
		
		displayAccel = (TextView) findViewById(R.id.displayAccel);
		displayLinAccel = (TextView) findViewById(R.id.displayLinAccel);
		displayGravitySensor= (TextView) findViewById(R.id.displayGS);
		displayGyroscope= (TextView) findViewById(R.id.displayGYS);
		displayALS= (TextView) findViewById(R.id.displayALS);
		displayAMFS= (TextView) findViewById(R.id.displayAMFS);
		displayProx= (TextView) findViewById(R.id.displayProx);
		displayBaro= (TextView) findViewById(R.id.displayBaro);
		displayATS= (TextView) findViewById(R.id.displayATS);
		
		PackageManager PM= this.getPackageManager();
		
		hasAccel = PM.hasSystemFeature(PackageManager.FEATURE_SENSOR_ACCELEROMETER);//accel,linAccel,gravity
		hasGys = PM.hasSystemFeature(PackageManager.FEATURE_SENSOR_GYROSCOPE);
		hasALS = PM.hasSystemFeature(PackageManager.FEATURE_SENSOR_LIGHT);
		hasAMFS = PM.hasSystemFeature(PackageManager.FEATURE_SENSOR_COMPASS);
		hasProx = PM.hasSystemFeature(PackageManager.FEATURE_SENSOR_PROXIMITY);
		hasBaro = PM.hasSystemFeature(PackageManager.FEATURE_SENSOR_BAROMETER);
		//boolean hasATS;
		
		if(!hasAccel){
			displayAccel.setText("N/A");
			displayLinAccel.setText("N/A");
			displayGravitySensor.setText("N/A");
		}
		if(!hasGys){displayGyroscope.setText("N/A");}
		if(!hasALS){displayALS.setText("N/A");}
		if(!hasAMFS){displayAMFS.setText("N/A");}
		if(!hasProx){displayProx.setText("N/A");}
		if(!hasBaro){displayBaro.setText("N/A");}
		
		
	}
	private String round(float input){
		
		String output =String.format( "%.1f", Math.sqrt(Math.pow(input, 2)));
		
		return output;
	}

	private void setInfo() {
		
		
		listener = new SensorEventListener(){

			@Override
			public void onSensorChanged(SensorEvent event) {
				Sensor sensor = event.sensor;
				
				if(sensor.getType()==Sensor.TYPE_ACCELEROMETER && hasAccel){
					displayAccel.setText("x:" +round(event.values[0]) + " y:" + round(event.values[1]) + " z:" + round(event.values[2]) + " m/s2");
				}
				
				if(sensor.getType()==Sensor.TYPE_LINEAR_ACCELERATION && hasAccel){
					displayLinAccel.setText("x:" +round(event.values[0]) + " y:" + round(event.values[1]) + " z:" + round(event.values[2]) + " m/s2");
				}
				if(sensor.getType()==Sensor.TYPE_GRAVITY && hasAccel){
					displayGravitySensor.setText("x:" +round(event.values[0]) + " y:" + round(event.values[1]) + " z:" + round(event.values[2]) + " m/s2");
				}
				if(sensor.getType()==Sensor.TYPE_GYROSCOPE && hasGys){
					displayGyroscope.setText("x:" +round(event.values[0]) + " y:" + round(event.values[1]) + " z:" + round(event.values[2]) + " rads");
				}
				if(sensor.getType()==Sensor.TYPE_LIGHT && hasALS){
					displayALS.setText(Math.round(event.values[0] * 100.0) / 100.0 + " lx");
				}
				if(sensor.getType()==Sensor.TYPE_MAGNETIC_FIELD && hasAMFS){
					displayAMFS.setText("x:" +round(event.values[0]) + " y:" + round(event.values[1]) + " z:" + round(event.values[2]) + " uT");
				}
				if(sensor.getType()==Sensor.TYPE_PROXIMITY && hasProx){
					displayProx.setText(Math.round(event.values[0] * 100.0) / 100.0 + " cm");
				}
				if(sensor.getType()==Sensor.TYPE_PRESSURE && hasBaro){
					displayBaro.setText(Math.round(event.values[0] * 100.0) / 100.0 + " hPa");
				}
				
				if(sensor.getType()==Sensor.TYPE_AMBIENT_TEMPERATURE){
					displayATS.setText(Math.round(event.values[0] * 100.0) / 100.0 + " C");
				}
				else{
					displayATS.setText("N/A");
				}
			}

			@Override
			public void onAccuracyChanged(Sensor sensor, int accuracy) {
			}
			
		};
		
	}
	

	
	public void onResume(){//start shake listener
		super.onResume();
		mngr.registerListener(listener, mngr.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), 
				SensorManager.SENSOR_DELAY_UI);
		mngr.registerListener(listener, mngr.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION), 
				SensorManager.SENSOR_DELAY_UI);
		mngr.registerListener(listener, mngr.getDefaultSensor(Sensor.TYPE_GRAVITY), 
				SensorManager.SENSOR_DELAY_UI);
		mngr.registerListener(listener, mngr.getDefaultSensor(Sensor.TYPE_GYROSCOPE), 
				SensorManager.SENSOR_DELAY_UI);
		mngr.registerListener(listener, mngr.getDefaultSensor(Sensor.TYPE_LIGHT), 
				SensorManager.SENSOR_DELAY_UI);
		mngr.registerListener(listener, mngr.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD), 
				SensorManager.SENSOR_DELAY_UI);
		mngr.registerListener(listener, mngr.getDefaultSensor(Sensor.TYPE_PROXIMITY), 
				SensorManager.SENSOR_DELAY_UI);
		mngr.registerListener(listener, mngr.getDefaultSensor(Sensor.TYPE_PRESSURE), 
				SensorManager.SENSOR_DELAY_UI);
		mngr.registerListener(listener, mngr.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE), 
				SensorManager.SENSOR_DELAY_UI);
		
	}
	
	@Override
	public void onPause(){//stops shake listener (to both reserve battery and error checking)
		super.onPause();
		mngr.unregisterListener(listener);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			Toast.makeText(this, "Version 1.0", Toast.LENGTH_SHORT).show();
			
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
