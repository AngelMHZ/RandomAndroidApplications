/*
 * Angel Hernandez
 * Comp 595MC
 * August 28, 2014
 * Project : Magic 8-ball app
 * Description: Created a Magic 8 Ball app that when launched has a button. 
 * 				When the button is pressed, one of twenty possible answers are 
 * 				displayed randomly.
 * Version:
 * 	1.0: Working Button with Toast as text output
 * 	2.0: Removed toast and displayed via text view
 *  2.1: Cosmetic changes, image background, button placement
 */


package com.example.magiceightball;

import java.util.Random;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends ActionBarActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		setupMessageButton();//Setup for Button interaction
	}

	private void setupMessageButton() {
		final Button messageButton = (Button) findViewById(R.id.MagicEightButton);//Finds button, sets it
		messageButton.setBackgroundColor(Color.WHITE);
		final TextView displayText = (TextView) findViewById(R.id.displayAnswer);
		
		messageButton.setOnClickListener(new View.OnClickListener() {//on click
			
			@Override
			public void onClick(View v) {//input command
				Log.i("ButtonPress", "Button Active");//view if button works
				displayText.setText(twentyResponses());
				messageButton.setText("Try Again");
				
			}
			
		});
	}

	protected CharSequence twentyResponses() {
		CharSequence[] list = {
				"It is certain",
				"It is decidedly so",
				"Without a doubt",
				"Yes definitely",
				"You may rely on it",
				"As I see it yes",
				"Most likely",
				"Outlook good",
				"Yes",
				"Signs point to yes",
				"Reply hazy try again",
				"Ask again later",
				"Better not tell you now",
				"Cannot predict now",
				"Concentrate and ask again",
				"Don't count on it",
				"My reply is no",
				"My sources say no",
				"Outlook not so good",
				"Very doubtful"};
		Random rand = new Random();
		return list[rand.nextInt(20)]; //0<=rand<20
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			Toast.makeText(this, "Version 2.1",Toast.LENGTH_LONG).show();
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}