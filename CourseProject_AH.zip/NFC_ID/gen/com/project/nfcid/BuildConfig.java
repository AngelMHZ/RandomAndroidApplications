/** Automatically generated file. DO NOT MODIFY */
package com.project.nfcid;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}