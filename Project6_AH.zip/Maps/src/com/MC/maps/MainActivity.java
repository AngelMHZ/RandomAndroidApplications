package com.MC.maps;

import com.google.android.gms.maps.*;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import android.support.v7.app.ActionBarActivity;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends ActionBarActivity {
	private GoogleMap map;
	private LocationManager locMngr;
	private LocationListener locListener;
	private SensorManager mngr;
	private SensorEventListener listener;
	private LatLng CURRENT_LOCATION;
	private LatLng PREVIOUS_LOCATION;
	private boolean firstLocationFound = false;
	private boolean firstStep = false;
	private float stepsAlreadyTaken;
	private TextView displaySteps;
	private TextView displayLimit;
	private boolean run;
	private float endAtStep = 5;
	private float currentSteps;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        locMngr = (LocationManager) getSystemService(LOCATION_SERVICE);
		mngr = (SensorManager) getSystemService(SENSOR_SERVICE);
        map = ((MapFragment) getFragmentManager().findFragmentById(R.id.map)).getMap();
        updateLocation();
        stepCounter();
    }
    private void stepCounter() {
    	displaySteps = (TextView) findViewById(R.id.stepCounter);
    	displayLimit = (TextView) findViewById(R.id.limit);
    	displaySteps.setText("Steps Taken: 0.0");
    	displayLimit.setText("End = " + endAtStep + " steps");
    	listener = new SensorEventListener(){

			@Override
			public void onSensorChanged(SensorEvent event) {
				
				Sensor sensor = event.sensor;
				if(currentSteps >= endAtStep && firstStep){
					map.addMarker(new MarkerOptions().position(CURRENT_LOCATION).title("End"));
					Toast.makeText(MainActivity.this, "You have reached your goal!", Toast.LENGTH_LONG).show();
					mngr.unregisterListener(listener);
					locMngr.removeUpdates(locListener);
				}
				if(sensor.getType()==Sensor.TYPE_STEP_COUNTER){
					if(!firstStep){//step_counter does not reset unless phone resets, this is a work around. 
						stepsAlreadyTaken = event.values[0];
						displayLimit.setText("End = " + endAtStep + " steps");
						firstStep = true;
					}
					else{
						displaySteps.setText("Steps Taken:" + (event.values[0]-stepsAlreadyTaken));//Minus the old steps taken outside the app to the new total.
						currentSteps = event.values[0]-stepsAlreadyTaken;
					}
				}
				
				if(sensor.getType()==Sensor.TYPE_ACCELEROMETER){
					
					if(event.values[1]> 19){//threshhold for running
						run = true;
					}
					else{
						run = false;
					}
						
				}
				
			}

			@Override
			public void onAccuracyChanged(Sensor sensor, int accuracy) {
			}
			
		};
		
	}
    
    public void increase(View v){
    	endAtStep+=5;
    	displayLimit.setText("End = " + endAtStep + " steps");
    }
    public void decrease(View v){
    	if(endAtStep-5 <0){
    		Toast.makeText(this, "Why are you trying to brake my app?", Toast.LENGTH_SHORT).show();
    	}
    	else{
    		endAtStep-=5;
        	displayLimit.setText("End = " + endAtStep + " steps");
    	}
    }
	private void updateLocation(){
		locListener = new LocationListener(){

			@Override
			public void onLocationChanged(Location location) {
				CURRENT_LOCATION = new LatLng(location.getLatitude(),location.getLongitude());
				
				if(CURRENT_LOCATION != null && !firstLocationFound){
					map.setMapType(GoogleMap.MAP_TYPE_HYBRID);
					CameraUpdate update = CameraUpdateFactory.newLatLngZoom(CURRENT_LOCATION, 16);
					map.animateCamera(update);
					
					map.addMarker(new MarkerOptions().position(CURRENT_LOCATION).title("Start"));
					firstLocationFound = true;
					map.addPolyline(new PolylineOptions().geodesic(true).add(CURRENT_LOCATION));
					PREVIOUS_LOCATION = CURRENT_LOCATION;
					
					map.setMyLocationEnabled(true);
					map.setTrafficEnabled(true);
				}
				
				else{
					if(run){
						map.addPolyline(new PolylineOptions().geodesic(true)
				                .add(PREVIOUS_LOCATION) 
				                .add(CURRENT_LOCATION).color(Color.RED)
				                );
					}
					else{
						map.addPolyline(new PolylineOptions().geodesic(true)
				                .add(PREVIOUS_LOCATION) 
				                .add(CURRENT_LOCATION).color(Color.GREEN)
				                );
					}
					 
					PREVIOUS_LOCATION = CURRENT_LOCATION;
				}
				
				
				
				
			}

			@Override
			public void onStatusChanged(String provider, int status,
					Bundle extras) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onProviderEnabled(String provider) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onProviderDisabled(String provider) {
				// TODO Auto-generated method stub
				
			}
			
		};
		locMngr.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 0, locListener);
		
		
	}









	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
        	
        	Toast.makeText(this, "Version 1.0", Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public void onResume(){//start shake listener
		super.onResume();
		mngr.registerListener(listener, mngr.getDefaultSensor(Sensor.TYPE_STEP_COUNTER), 
				SensorManager.SENSOR_DELAY_UI);
		mngr.registerListener(listener, mngr.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), 
				SensorManager.SENSOR_DELAY_UI);
		locMngr.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 0, locListener);
	}
    
    public void onPause(){//stops shake listener (to both reserve battery and error checking)
		super.onPause();
		mngr.unregisterListener(listener);
		locMngr.removeUpdates(locListener);
	}
}
