package com.MC.maps;

import com.google.android.gms.maps.*;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import android.support.v7.app.ActionBarActivity;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;


public class MainActivity extends ActionBarActivity {
	private GoogleMap map;
	private LocationManager mngr;
	private LocationListener listener;
	private LatLng CURRENT_LOCATION;
	private LatLng PREVIOUS_LOCATION;
	private boolean firstLocationFound = false;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mngr = (LocationManager) getSystemService(LOCATION_SERVICE);
        map = ((MapFragment) getFragmentManager().findFragmentById(R.id.map)).getMap();
        updateLocation();
    }
    private void updateLocation(){
		listener = new LocationListener(){

			@Override
			public void onLocationChanged(Location location) {
				CURRENT_LOCATION = new LatLng(location.getLatitude(),location.getLongitude());
				
				if(CURRENT_LOCATION != null && !firstLocationFound){
					map.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
					CameraUpdate update = CameraUpdateFactory.newLatLngZoom(CURRENT_LOCATION, 16);
					map.animateCamera(update);
					
					map.addMarker(new MarkerOptions().position(CURRENT_LOCATION).title("Start"));
					firstLocationFound = true;
					map.addPolyline(new PolylineOptions().geodesic(true).add(CURRENT_LOCATION));
					PREVIOUS_LOCATION = CURRENT_LOCATION;
				}
				
				else{
					 map.addPolyline(new PolylineOptions().geodesic(true)
				                .add(PREVIOUS_LOCATION) 
				                .add(CURRENT_LOCATION).color(Color.RED)
				                );
					PREVIOUS_LOCATION = CURRENT_LOCATION;
				}
				
				
				
				
			}

			@Override
			public void onStatusChanged(String provider, int status,
					Bundle extras) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onProviderEnabled(String provider) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onProviderDisabled(String provider) {
				// TODO Auto-generated method stub
				
			}
			
		};
		mngr.requestLocationUpdates(LocationManager.GPS_PROVIDER, 100, 0, listener);
		
		
	}









	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
        	
        	Toast.makeText(this, "Version 1.0", Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
