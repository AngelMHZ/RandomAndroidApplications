/*
 * Angel Hernandez
 * Comp 595MC
 * August 28, 2014
 * Project : Magic 8-ball app
 * Description: Created a Magic 8 Ball app that when launched has a button. 
 * 				When the button is pressed, one of twenty possible answers are 
 * 				displayed randomly.
 * Version:
 * 	1.0: Working Button with Toast as text output
 * 	2.0: Removed Toast and displayed via text view
 * 	2.1: Cosmetic changes, image background, button placement changes
 * 	3.0: Flip implemented
 */


package com.example.magiceightballwithsensor;

import java.util.Random;

import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;



public class MainActivity extends ActionBarActivity {
	
	private SensorManager mngr;
	private Sensor accel;
	private SensorEventListener listener;
	private float mAccelCurrent;
	private float mAccelLast;
	private float mAccel;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		setupMessageButton();//Setup for Button interaction
		setupFlipInteraction();//setup for Shake interaction
	}

	private void setupMessageButton() {
		final Button messageButton = (Button) findViewById(R.id.MagicEightButton);//Finds button, sets it
		messageButton.setBackgroundColor(Color.WHITE);
		messageButton.setOnClickListener(new View.OnClickListener() {//on click
			
			@Override
			public void onClick(View v) {//input command
				displayAnswer();
				messageButton.setText("Try Again");
			}
		});
	}
	
	private void setupFlipInteraction() {
		final Button messageButton = (Button) findViewById(R.id.MagicEightButton);//Finds button, sets it
		messageButton.setBackgroundColor(Color.WHITE);
		
		mngr = (SensorManager) getSystemService(SENSOR_SERVICE);
		accel = mngr.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		listener = new SensorEventListener(){

			@Override
			public void onSensorChanged(SensorEvent event) {
				float z = event.values[2];
				 mAccelLast = mAccelCurrent;
			     mAccelCurrent = z;
			     float delta = mAccelCurrent - mAccelLast;
			     mAccel = mAccel * 0.9f + delta; // perform low-cut filter
			     	
			     if(mAccel >12){
						displayAnswer();
						messageButton.setText("Flip Again");
			     }
				
			}

			@Override
			public void onAccuracyChanged(Sensor sensor, int accuracy) {
				// Don't need
				
			}
			
		};
		
	}
	
	@Override
	public void onResume(){//start shake listener
		super.onResume();
		mngr.registerListener(listener, accel, 
				SensorManager.SENSOR_DELAY_UI);
	}
	
	@Override
	public void onPause(){//stops shake listener (to both reserve battery and error checking)
		super.onPause();
		mngr.unregisterListener(listener);
		
	}

	


	private void displayAnswer() {
		Log.i("ButtonPress", "Button Active");//view if button works
		TextView displayText = (TextView) findViewById(R.id.displayAnswer);
		displayText.setText(twentyResponses());
	}
	
	protected CharSequence twentyResponses() {
		CharSequence[] list = {
				"It is certain",
				"It is decidedly so",
				"Without a doubt",
				"Yes definitely",
				"You may rely on it",
				"As I see it yes",
				"Most likely",
				"Outlook good",
				"Yes",
				"Signs point to yes",
				"Reply hazy try again",
				"Ask again later",
				"Better not tell you now",
				"Cannot predict now",
				"Concentrate and ask again",
				"Don't count on it",
				"My reply is no",
				"My sources say no",
				"Outlook not so good",
				"Very doubtful"};
		Random rand = new Random();
		return list[rand.nextInt(20)]; //0<=rand<20
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			Toast.makeText(this, "Version 3.0", Toast.LENGTH_SHORT).show();
			
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
